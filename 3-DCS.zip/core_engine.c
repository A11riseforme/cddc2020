/*********** please try this : gcc helper.c && ./a.out ***********/ 
char*d="<I7!EB!'}?!*c7b;!*c<b6!*c+7a3""!*cC`1!*c9-b.!*cEb-!*cEd+!*"
"c44d*!*cGd)!*cHc)!*c(Bd(!*cGd)!"         "*cGd)!*cFd*!*c.:c+!*cEc"
",!*cDc-!*c7.b/!*cBa1!*c?"                     "`5!*c;c6!*c"  "9b9"
"!'~]=!H?!5R!<I7!EB!"           "'}?!*c7b;!"         "*c<b6"  "!*c"
"+7a3!*cC`1!*c9-"         "b.!*cEb-!*cEd+!*c44d*!*c"     ""   "Gd)"
"!*cHc)!*c(Bd("        "!*cGd)!*cGd)!*cF""d*!*c.:c+!*c"       "Ec,"
"!*cDc-!*c7."        "b/!*cBa1!*c?`5!*c;c6!*c9b9!'~]=!H?"     "!5R"
"!<A?!Ce;!"       "<q/^'!7g.e)^'!""3e<a$_'!1d40c'!/dFa'!-c"   "2;_"
"'!+dM^'"        "!*d1@]'!)eP'!(e:1/!'fV!'e-<2!'e@9!'eW!'f3"  "9.!"
"(fC-)!"        ")f3;])!*fJ]*!""+f63^+!-fD^,!/f@^.!4b<`/!8b3" "b2!"
"<r5!D"         "c<!G@!<A?!Ce;!<q/^'!7g.e)^'!3e<a$_'!1d40c'!/""dFa"
"'!-c"         "2;_'!+dM^'!*d1@]'!)eP'""!(e:1/!'fV!'e""-<2!'e@9!'e"
"W!'"          "f39.!(fC-)!)f3;])!*fJ]*!+f63^+!-fD^,!/f@^.!4b<`/!8"
"b3b"         "2!<r5!Dc<""!G@!*i]5471[=ohr&r;026*o""*t*q*`*d*v*~=h"
"./}"         "tcrsth&t:r9b].,b-766-.t--//#""r[<t8-752693?<.~;b].t"
"--+"         "r/#537-r[/9~X.v90<6/<.v;-52/={kgoh./}q;uvtohr`.i*$e"
"ngt"          ",b;$/=t;v;6=`it"".`;7=`:,b-766=/o`..d;""b]`--[/+55"
"/}o`"          ".d:-?5/}o`.'v/i]q--[;52=`it.o;5""3-.v96<7/""=o:d="
"o--/i"          "]q--[;h./=i]q--""[;v9h./<-52={cjuc&`it.o" ";?4=o"
":d=o--"          "/i]q--[;54={cjuc&i]q--[;76=i]q[;6=vsru" ".i/={="
"),ebbeY"          "er`,)=&",o[3217];int t=640,i,r,w,f,b  ,p,x;n(){
return r<t?          d[(*d+100+(r++))%t]:r>+1340?59:(x=  d[(r++-t)%
351+t])?x^(p?          6:0):(p=+34);}main(){w=sprintf  (o,"char*d="
);r=p=0;for(f=1;f<      *d+100;)if((b=d[f++])-33){    if(b<+93){if(
!p)o[w++]=34;for(i=35+      (p?0:1);i<b;i++)o      [w++]=n();o[w++]
=p?n():+34;}else for(i=92;                      i<b;i++)o[w++]=32;}
else o[w++]=10;o[w]=0;puts(o);};/*        this_is_triple_compiling_
alorithm_for_ccddc_ctf_please_enjoy_!_Lorem_ipsum_dolor_sit_amet_*/

